from .cgpa_calc import CGPACalculator
